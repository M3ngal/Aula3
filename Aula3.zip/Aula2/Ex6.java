import java.util.Scanner;

public class Ex6 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o valor inicial da dívida: ");
        int vi = sc.nextInt();
        System.out.println("Digite a porcentagem de juros: ");
        double j = sc.nextDouble();
        System.out.println("Digite o número de meses da dívida: ");
        int n = sc.nextInt();
        double vf = vi * Math.pow(1 + j / 100, n);
        System.out.println("O valor da dívida é " + vf);
        sc.close();
    }
}
