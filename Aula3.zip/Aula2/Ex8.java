import java.util.Scanner;

public class Ex8 {
     public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite um ângulo: ");
        double a = sc.nextDouble();
        System.out.println("Seno: " + Math.sin(Math.toRadians(a)));
        System.out.println("Cosseno: " + Math.cos(Math.toRadians(a)));
        System.out.println("Tangente: " + Math.tan(Math.toRadians(a)));
        System.out.println("Secante: " + 1 / Math.cos(Math.toRadians(a)));
        System.out.println("Cossecante: " + 1 / Math.sin(Math.toRadians(a)));
        System.out.println("Cotangente: " + 1 / Math.tan(Math.toRadians(a)));
        sc.close();
     }
}
