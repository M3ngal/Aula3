import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Ex5 {
    public static void LerArquivo(String nomeArquivo){
        String [] lista = new String[10];
        int i = 0;
        try{
            File arquivo = new File(nomeArquivo);
            Scanner sc = new Scanner(arquivo);
            while(sc.hasNext()){
                lista [i] = sc.nextLine();
                i++;
            }
            for(int j = 9; j >= 0; j--){
                System.out.println(lista[j]);
            }
            sc.close();

        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }
    }
    public static void main(String [] args){
        LerArquivo("Palavras.txt");
    }
}
