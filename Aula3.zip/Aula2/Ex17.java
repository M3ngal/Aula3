import java.util.Scanner;

public class Ex17 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite um numero: ");
        double a = sc.nextDouble();
        double b = Math.pow(a,2);
        double c = Math.sqrt(a);
        System.out.println("O numero é " + a + "\n" + "O quadrado do numero é " + b + "\n" + "A raiz do numero é " + c);
        sc.close();
    }
}
