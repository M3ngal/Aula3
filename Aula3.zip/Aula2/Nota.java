import javax.swing.*;

public class Nota{
    public static void main(String [] args){
        String a = JOptionPane.showInputDialog("Digite o nome do comprador: ");
        String b = JOptionPane.showInputDialog("Digite o produto adquirido: ");
        String c = JOptionPane.showInputDialog("Digite a quantidade adquirida do produto: ");
        String d = JOptionPane.showInputDialog("Digite o preço do produto: ");
        JOptionPane.showMessageDialog(null, "• " + a + "\n" + "• "+ b + "\n" + "• " + c + "\n" + "• " + d);
    }  
}
