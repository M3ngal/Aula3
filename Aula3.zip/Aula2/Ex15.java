import java.util.Scanner;

public class Ex15 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o raio do circulo: ");
        double a = sc.nextDouble();
        double b = Math.pow(a,2) * Math.PI;
        System.out.println("A área do circulo é " + b);
        sc.close();
    }
}
