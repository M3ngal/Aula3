import javax.swing.JOptionPane;

public class Ex3 {
    public static void main(String[] args){
        double a = Double.parseDouble(JOptionPane.showInputDialog("Digite um número: "));
        double b = Math.pow(a,2.0);
        JOptionPane.showMessageDialog(null, "O quadrado é: "+ b);
    }
}
