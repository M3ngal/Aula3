import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Ex1{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/mm/aaaa");
        System.out.print("Digite a data do seu nascimento(dd/mm/aaaa): ");
        String d1 = sc.nextLine();
        System.out.print("Digite a data de hoje(dd/mm/aaaa): ");
        String d2 = sc.nextLine();
        LocalDate data1 = LocalDate.parse(d1, f);
        LocalDate data2 = LocalDate.parse(d2, f);
        long dif = ChronoUnit.DAYS.between(data1, data2);
        System.out.println("Você está vivo a" + Math.abs(dif) + " dias");
        sc.close();
    }  
}