import javax.swing.*;

public class Ex2 {
    public static void main(String[] args){
    int a = Integer.parseInt(JOptionPane.showInputDialog("Digite a altura do retângulo: "));
    int b = Integer.parseInt(JOptionPane.showInputDialog("Digite o comprimento do retângulo: "));
    int c = a * b;
    JOptionPane.showMessageDialog(null, "A área do retângulo é: "+ c);
    }
}
