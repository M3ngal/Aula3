import java.util.Scanner;

public class Ex20 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o primeiro lado do triangulo: ");
        double a = sc.nextDouble();
        System.out.println("Digite o segundo lado do triangulo: ");
        double b = sc.nextDouble();
        double c = Math.sqrt(Math.pow(a,2) * Math.pow(b,2));
        System.out.println("A área do triangulo é " + c);
        sc.close();
    }
}
