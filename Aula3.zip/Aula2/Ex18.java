import java.util.Scanner;

public class Ex18 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a base do triangulo: ");
        double a = sc.nextDouble();
        System.out.println("Digite a altura do triangulo: ");
        double b = sc.nextDouble();
        double c = (a * b) / 2;
        System.out.println("A área do triangulo é " + c);
        sc.close();
    }
}
