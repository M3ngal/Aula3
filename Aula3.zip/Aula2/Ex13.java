import java.util.Scanner;

public class Ex13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a data (dd/mm/aa): ");
        String a = sc.nextLine();
        System.out.println("O dia é " + a.substring(0,2) + "\n" + "O mês é " + a.substring(3,5) + "\n" + "O ano é " + a.substring(6,8));
        sc.close();
    }
}