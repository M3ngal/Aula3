import java.util.Scanner;

public class Ex4 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a primeira frase: ");
        String F1 = sc.nextLine();
        System.out.println("Digite a segunda frase: ");
        String F2 = sc.nextLine();
        System.out.println("Digite a terceira frase: ");
        String F3 = sc.nextLine();
        String c = F1 + F2 + F3;
        int d = c.length();
        System.out.println("O comprimento das frases combinadas é " + d);
        sc.close();
    }
}
