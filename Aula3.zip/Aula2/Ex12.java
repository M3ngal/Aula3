import java.util.Scanner;

public class Ex12 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a data: ");
        int a = sc.nextInt();
        int b = a / 10000;
        int c = (a - (b * 10000))/100 ;
        int d = (a - (a / 100) * 100);
        if(b >= 10){
            System.out.println("O dia é " + b);
        }
        else {
            System.out.println("O dia é 0" + b);
        }
        if(c >= 10){
            System.out.println("O mês é " + c);
        }
        else {
            System.out.println("O mês é 0" + c);
        }
        if(d >= 10){
            System.out.println("O ano é " + d);
        }
        else {
            System.out.println("O ano é 0" + d);
        }
        sc.close();
    }
}
