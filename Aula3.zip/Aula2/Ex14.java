import java.util.Scanner;

public class Ex14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite um número: ");
        double a = sc.nextDouble();
        System.out.println("Digite um número: ");
        double b = sc.nextDouble();
        System.out.println("Digite um número: ");
        double c = sc.nextDouble();
        double d = 2 * ((a - c) / 8) - b * 5;
        System.out.println("O resultado da operação é " + d);
        sc.close();

    }
}
