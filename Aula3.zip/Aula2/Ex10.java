import java.util.Scanner;

public class Ex10 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite um número: ");
        double a = sc.nextDouble();
        System.out.println("Digite a base do logaritmo: ");
        double b = sc.nextDouble();
        System.out.println("O seu logaritmo é " + Math.log(a) / Math.log(b));
        sc.close();
    }
}
