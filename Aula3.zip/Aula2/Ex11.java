import java.util.Scanner;

public class Ex11 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a primeira frase: ");
        String a = sc.nextLine();
        System.out.println("Digite a segunda frase: ");
        String b = sc.nextLine();
        System.out.println("Digite a terceira frase: ");
        String c = sc.nextLine();
        System.out.println(a + b + c);
        System.out.println(b.substring(0,b.length()/2) + c.substring(c.length()/2,c.length()) + b.substring(b.length()/2,b.length()) + a.substring(0,a.length()/2) + c.substring(0,c.length()/2) + a.substring(a.length()/2,a.length()));
        sc.close();
    }
}
