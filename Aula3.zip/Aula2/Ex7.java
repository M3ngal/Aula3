import java.util.Scanner;

public class Ex7 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite um número inteiro com 5 digitos: ");
        String a = sc.nextLine();
        System.out.println("O algarismo da dezena é " + a.substring(3,4));
        sc.close();
    }
}
