import java.util.Scanner;

public class Ex16 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o divisor: ");
        int a = sc.nextInt();
        System.out.println("Digite o dividendo: ");
        int b = sc.nextInt();
        int c = a / b;
        int d = a % b;
        System.out.println("O dividendo é " + b + "\n" + "O divisor é " + a + "\n" + "O quociente é " + c + "\n" + "O resto é " + d);
        sc.close();
    }
}
